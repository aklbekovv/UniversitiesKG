package com.flaterlab.uskg.models;

import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class University {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("abbreviation")
    @Expose
    private String abbreviation;
    @SerializedName("school-type")
    @Expose
    private String schoolType;
    @SerializedName("founded")
    @Expose
    private String founded;
    @SerializedName("location")
    @Expose
    private String location;
    @SerializedName("rating")
    @Expose
    private Rating rating;
    @SerializedName("campus")
    @Expose
    private List<Campu> campus = null;
    @SerializedName("most-popular-major")
    @Expose
    private List<MostPopularMajor> mostPopularMajor = null;
    @SerializedName("students")
    @Expose
    private Integer students;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getSchoolType() {
        return schoolType;
    }

    public void setSchoolType(String schoolType) {
        this.schoolType = schoolType;
    }

    public String getFounded() {
        return founded;
    }

    public void setFounded(String founded) {
        this.founded = founded;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Rating getRating() {
        return rating;
    }

    public void setRating(Rating rating) {
        this.rating = rating;
    }

    public List<Campu> getCampus() {
        return campus;
    }

    public void setCampus(List<Campu> campus) {
        this.campus = campus;
    }

    public List<MostPopularMajor> getMostPopularMajor() {
        return mostPopularMajor;
    }

    public void setMostPopularMajor(List<MostPopularMajor> mostPopularMajor) {
        this.mostPopularMajor = mostPopularMajor;
    }

    public Integer getStudents() {
        return students;
    }

    public void setStudents(Integer students) {
        this.students = students;
    }

}