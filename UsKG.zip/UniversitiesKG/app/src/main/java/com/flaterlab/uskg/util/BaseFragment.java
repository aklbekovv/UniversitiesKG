package com.flaterlab.uskg.util;

import androidx.fragment.app.Fragment;

abstract public class BaseFragment extends Fragment {

}
