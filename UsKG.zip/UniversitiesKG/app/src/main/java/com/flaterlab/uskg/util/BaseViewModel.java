package com.flaterlab.uskg.util;

import androidx.lifecycle.ViewModel;

abstract public class BaseViewModel extends ViewModel {

}
